<?php
/**
 * LOCALIZABLE STRINGS - English
 *
 * $Id: lang/english.inc.php, 2005/01/21 22:22:19 Exp $
 */

if (stristr($_SERVER['PHP_SELF'], ".inc.php")){
	die("good-bye, world! :-P");
}
$lang['manual']         = '설명서';
$lang['anchor']         = '<a href="' . $_SERVER['PHP_SELF'] . '"> English </a>, 
                           <a href="' . $_SERVER['PHP_SELF'] . '?ex-lang=ja"> 日本語 </a>';
$lang['title']          = '안녕하세요. P_BLOG입니다.';
$lang['define_p_blog']  = 'P_BLOG는 PHP+MySQL을 기반으로 하는 설치형 블로그 시스템입니다. '.
                          '일반적인 로그 관리 기능 외에 주된 기능으로는 파일 업로드, 억세스 해석, '.
                          '댓글/포럼, 트랙백, Ping 전송, 독자적인 컨텐츠 확장 기능인 "Vars" 등이 있습니다</p>'.
                          '<p>P_BLOG는 <abbr title="GNU Public License">GPL</abbr> 기반의 오픈 소스이며 '.
                          '<abbr title="&quot;프리&quot;라는 것은 제한 없이 쓸 수 있다는 것이지 가격의 문제가 아닙니다.">프리 소프트웨어</abbr>로 '.
                          '<abbr title="World Wide Web Consortium">W3C</abbr>의 XHTML1.0 Strict 또는 XHTML1.1를 지원합니다.</p>';
$lang['license']        = '라이센스';
$lang['check_env']      = '환경 점검';
$lang['software']       = '소프트웨어';
$lang['requirements']   = '권한';
$lang['your_env']       = '사용자 환경';
$lang['permissions']    = '권한';
$lang['status']         = '상태';
$lang['os_independent'] = 'OS에 독립적임';
$lang['check_perms']    = '권한 점검';
$lang['target']         = '대상';
$lang['next']           = '계속';

$lang['set_dbname']     = '"user_config.inc.php"에 DB 이름을 설정해 주세요.';
$lang['set_log_table']  = '"user_config.inc.php"에 로그 테이블의 이름을 설정해 주세요.';
$lang['set_info_table'] = '"user_config.inc.php"에 파일 정보 테이블의 이름을 설정해 주세요.';
$lang['set_data_table'] = '"user_config.inc.php"에 파일 데이타 테이블의 이름을 설정해 주세요.';
$lang['set_ana_table']  = '"user_config.inc.php"에 억세스 해석 테이블의 이름을 설정해 주세요.';
$lang['set_user_table'] = '"user_config.inc.php"에 사용자 테이블의 이름을 설정해 주세요.';
$lang['set_conf_table'] = '"user_config.inc.php"에 환경 설정 테이블의 이름을 설정해 주세요.';
$lang['set_tb_table']   = '"user_config.inc.php"에 트랙백 테이블의 이름을 설정해 주세요.';

$lang['set_host_name']  = 'MySQL 서버 주소를 입력해 주세요.';
$lang['set_user_name']  = 'MySQL 아이디를 입력해 주세요.';
$lang['set_user_pass']  = 'MySQL 비밀번호를 입력해 주세요.';
$lang['set_admin_dir']  = '관리자용 디렉토리의 이름을 "admin-dir"에서 다른 것으로 변경해 주세요.';
$lang['admin_dir_exp']  = '관리자용 디렉토리의 이름이 "admin-dir"인 상태에서는 작동하지 않습니다. '.
                          '백도어를 숨기는 것으로 보안을 강화할 수 있습니다. 원하는 이름으로 바꿔주세요. ';
$lang['rewrite_dbname'] = 'DB 이름을 입력해 주세요.';
$lang['rewrite_dbname_msg'] = '특별히 바꿀 필요가 없다면 기본설정을 써도 좋습니다.';
$lang['connect_error']  = '현재 MySQL DB에 접속할 수 없습니다.';
$lang['connect_error_msg'] = '아래의 세 개의 설정중 하나라도 일치하지 않으면 MySQL DB에 접속할 수 없습니다.';
$lang['rewrite_host']   = 'MySQL 서버 주소를 한번 더 확인해 주세요.';
$lang['rewrite_user']   = 'MySQL 아이디를 한번 더 확인해 주세요.';
$lang['rewrite_pass']   = 'MySQL 비밀번호를 한번 더 확인해 주세요.';
$lang['perm_looks_ok']  = '읽고 쓰는 권한이 있습니다. OK.';
$lang['perm_looks_bad'] = '읽고 쓰는 권한이 없습니다. 권한을 변경해 주세요.';
$lang['no_resoures']    = '"resources" 디렉토리를 찾을 수 없습니다.';
$lang['no_user_inc']    = '"user_include" 디렉토리를 찾을 수 없습니다.';
$lang['no_menu']        = '"menu.inc.php" 파일을 찾을 수 없습니다.';
$lang['no_css_rss']     = '"css_rss.inc.php" 파일을 찾을 수 없습니다.';
$lang['no_base_xhtml']  = '"base_xhtml.inc.php" 파일을 찾을 수 없습니다.';
$lang['no_user_conf']   = '"user_config.inc.php" 파일을 찾을 수 없습니다.';

$lang['save_settings']  = '저장';
$lang['settings']       = '환경설정';
$lang['root_path_settings'] = '최상위 디렉토리의 설정';
$lang['root_path_ex']   = '설치한 P_BLOG의 최상위 디렉토리를 설정합니다. "http://yourdomain.com/"는 입력할 필요가 없습니다. '.
                          '<br />앞뒤로 "/(슬래쉬)"는 반드시 필요합니다.';
$lang['choose_default_lang'] = '기본 언어를 설정해 주세요.';
$lang['choose_time_zone']    = '시간대를 설정해 주세요';
$lang['install_or_upgrade'] = '설치 또는 업그레이드';
$lang['install_ex']     = '새로 설치를 할 것인가 업그레이드를 할 것인가 결정한 후 시작 버튼을 눌러 주세요.';
$lang['install']        = '새로 설치';
$lang['upgrade']        = '업그레이드';
$lang['start']          = '시작!';
$lang['back_to_step2']  = 'STEP-2로 돌아가 주세요';
$lang['step']           = '스텝';
$lang['results']        = '결과';
$lang['create_db']      = 'DB를 생성';
$lang['select_db']      = 'DB를 선택';
$lang['create_table']   = '테이블을 생성';
$lang['create_field']   = '：필드를 생성：';
$lang['installed_defaults'] = '기본 설정값으로 설치 ';
$lang['finished']       = ' 설치 완료';
$lang['install_fin_msg'] =<<<EOD
<p>설치가 끝났습니다. P_BLOG를 사용하기 전에 관리용 아이디와 비밀번호를 만들어야 합니다. 아래의 순서대로 아이디와 비밀번호를 만들어 주세요.</p>
<ol>
<li>아래의 링크를 눌러 "어카운트 매니저"로 이동합니다.<br />
<div class="command"><p class="ref"><a href="../{$admin_dir}/root/root_login.php">../{$admin_dir}/root/root_login.php</a></p></div></li>
<li>MySQL의 아이디와 비밀번호를 입력해 로그인한 후, 관리용 아이디와 비밀번호를 만듭니다.</li>
<li>새로 만든 관리용 아이디와 비밀번호를 사용해 관리 화면으로 로그인합니다. 관리 화면의 주소는 아래와 같습니다.<br />
<div class="command"><p class="ref"><a href="../{$admin_dir}/login.php">../{$admin_dir}/login.php</a></p></div></li>
<li>관리 화면으로 로그인에 성공했다면, 이 관리용 아이디와 비밀번호로 환경 설정, 글의 작성, 수정, 삭제등을 할 수 있습니다. (MySQL의 아이디와 비밀번호로는 글의 작성, 수정, 삭제등을 할 수 없습니다.)</li>
</ol>
<div class="important">
<p>설치가 끝난 후에는 &quot;SETUP&quot; 디렉토리를 지워 주세요.</p>
</div>
<p>P_BLOG를 즐겁게 사용하시길 바랍니다.<br />
피드백이나 버그 레포팅등은 부담없이 포럼이나 메일을 활용해 주세요.</p>
EOD;
?>